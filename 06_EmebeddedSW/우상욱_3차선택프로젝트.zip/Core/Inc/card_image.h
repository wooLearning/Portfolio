/*
 * card_image.h
 *
 *  Created on: Jan 23, 2025
 *      Author: user
 */

#ifndef INC_CARD_IMAGE_H_
#define INC_CARD_IMAGE_H_

#include "j_image.h"
#include "q_image.h"
#include "k_image.h"
#include "back_image.h"
#include "joker_image.h"


#endif /* INC_CARD_IMAGE_H_ */
