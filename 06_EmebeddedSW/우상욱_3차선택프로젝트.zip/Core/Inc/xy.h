/*
 * xy.h
 *
 *  Created on: Jan 23, 2025
 *      Author: user
 */

#ifndef INC_XY_H_
#define INC_XY_H_

#define X0 0
#define Y0 0

#define X1 80
#define Y1 0
#define X2 160
#define Y2 0

#define X3 0
#define Y3 107
#define X4 80
#define Y4 107
#define X5 160
#define Y5 107

#define X6 0
#define Y6 214
#define X7 80
#define Y7 214
#define X8 160
#define Y8 214

#endif /* INC_XY_H_ */
